/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nimapp;
import java.lang.NumberFormatException;
//import static java.sql.JDBCType.NULL;

/**
 *
 * @author Candace
 */
public class NimGame {
   int lengthofarray = 3;
   int[] initialSticks = new int[lengthofarray]; //this makes the initial sticks in this program an array of 3 elements
   int r = 0; //constructor for initial r.(row)
   int s = 0;//constructor for initial s (number to take from row)
   
public NimGame(int[] initialSticks){ //this makes all the elements of this game equal to those that are being passed in.
    for (int i = 0; i < 3; i++){
        if(initialSticks[i] <= 0){
            throw new IllegalNumberException();
        }
    }
    this.initialSticks[0] = initialSticks[0];
    this.initialSticks[1] = initialSticks[1];
    this.initialSticks[2] = initialSticks[2];
    
    int r = this.r;
    int s = this.s;

}

public int getRow(int r){

if(r == 0){ 
    return initialSticks[0]; 
}
if (r == 1){
    return initialSticks[1];
}
if(r == 2){
    return initialSticks[2];
}
if(r != 0 && r!= 1 && r != 2){ //in the case that the row is not 0 1 or 2, it will be given a no such row exception
    throw new NoSuchRowException();
}
return 0;
}

public void play(int r, int s){
    
    
if((r == 0) && (initialSticks[0] > 0)){ //if the row is 0 and the first element of the array is greater than zero, continue.
    if(s > initialSticks[0] || s > 3 || s < 1){ //if the number of that element is greater than 3, throw an exception
        throw new IllegalSticksException();
    }
    else if((initialSticks[0] + initialSticks[1] + initialSticks[2]) == 0){//if the elements add up to zero, throw an exception
    throw new NotEnoughSticksException();
    }
    else{ //if both if statements above pass, then the initialsticks will be the initial sticks minus the s given.
        initialSticks[0] = initialSticks[0] - s;
    }
}
if((r == 1) && (initialSticks[1] > 0)){//if the row is 1 and the first element of the array is greater than zero, continue.
    if(s > initialSticks[1] || s > 3 || s < 1){//if the number of that element is greater than 3, throw an exception
        throw new IllegalSticksException();
    }
    else if((initialSticks[0] + initialSticks[1] + initialSticks[2]) == 0){//if the elements add up to zero, throw an exception
    throw new NotEnoughSticksException();
}
    else{
        initialSticks[1] = initialSticks[1] - s;//if both if statements above pass, then the initialsticks will be the initial sticks minus the s given.
    }
}
if((r == 2) && (initialSticks[2] > 0)){//if the row is 2 and the first element of the array is greater than zero, continue.
    if(s > initialSticks[2] || s > 3 || s < 1){ //if the number of that element is greater than 3, throw an exception
        throw new IllegalSticksException();
    }
    else if((initialSticks[0] + initialSticks[1] + initialSticks[2]) == 0){//if the elements add up to zero, throw an exception
        throw new NotEnoughSticksException();
    }
    else{
        initialSticks[2] = initialSticks[2] - s;//if both if statements above pass, then the initialsticks will be the initial sticks minus the s given.
    }
}
if(((r != 0) && (r != 1) && (r != 2)) || (s != 1 && s!= 2 && s!= 3) ){//if the r is neither 0, 1, or 2, throw an exception
    if((r != 0) && (r != 1) && (r != 2)){
    throw new NoSuchRowException();
    
}
    else{
        throw new IllegalSticksException();
    }
}
}

public boolean isOver(){ //if all of the sticks add up to 0, the game is over.
if((initialSticks[0] + initialSticks[1] + initialSticks[2] == 0))
{
    return true;
}
else{
    return false;
}
}

public void AIMove(){
  
int randomnum = (int)(Math.random()*3 + 1);//makes a random number for the computers 's'
int randrow = (int)(Math.random()*3 + 1);//makes a random row
if(randomnum > initialSticks[randrow] || randrow > 3 || randrow < 1){ //if the 's' is greater than the row's sticks, go through loop
while(randomnum > initialSticks[randrow] || randrow > 3 || randrow < 1){ //this loop will continue until a proper 's' and 'r' is found
    randomnum = (int)(Math.random()*3 + 1);
    randrow = (int)(Math.random()*3 + 1);
}
play(randrow, randomnum);
}
else{
    play(randrow, randomnum);
}
}

public String toString(){ //toString method for debugging.
return "Strings in section 1: " + initialSticks[0] + "Strings in section 2: " + initialSticks[1] + "Strings in sectino 3: " + initialSticks[2];
}

}
