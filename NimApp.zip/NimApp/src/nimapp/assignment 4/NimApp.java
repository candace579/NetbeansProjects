/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nimapp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.NumberFormatException;

public class NimApp extends JFrame implements ActionListener {

    public final int ROWS = 3;
    private JTextField[] gameFields; // Where sticks for each row shown
    private JTextField rowField;     // Where player enters row to select
    private JTextField sticksField;  // Where player enters sticks to take
    private JButton playButton;      // Pressed to take sticks
    private JButton AIButton;        // Pressed to make AI's move
    private NimGame nim;

    public NimApp() {
        // Build the fields for the game play 
        rowField = new JTextField(5);
        sticksField = new JTextField(5);
        playButton = new JButton("PLAYER");
        AIButton = new JButton("COMPUTER");
        playButton.addActionListener(this);
        AIButton.addActionListener(this);
        AIButton.setEnabled(false);
        // Create the layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        getContentPane().add(mainPanel);
        
        JPanel sticksPanel = new JPanel(new GridLayout(3, 1));
        mainPanel.add(sticksPanel, BorderLayout.EAST);

        JPanel playPanel = new JPanel(new GridLayout(3, 2));
        mainPanel.add(playPanel, BorderLayout.CENTER);

        // Add the fields to the play panel
        playPanel.add(new JLabel("Row: ", JLabel.RIGHT));
        playPanel.add(rowField);
        playPanel.add(new JLabel("Sticks: ", JLabel.RIGHT));
        playPanel.add(sticksField);
        playPanel.add(playButton);
        playPanel.add(AIButton);

        // Build the array of textfields to display the sticks
        gameFields = new JTextField[ROWS];
        
        for (int i = 0; i < ROWS; i++) {
            gameFields[i] = new JTextField(10);
            gameFields[i].setEditable(false);
            sticksPanel.add(gameFields[i]);
        }
        
        
        setSize(350, 150);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        try{ // this try block makes sure that all of the numbers entered are 1 or more
        nim = new NimGame(new int[]{3, 5, 7});
        }
        catch(IllegalNumberException ex){
            JOptionPane.showMessageDialog(null, "Sorry, you can not have a negative number of sticks.");
        }
        draw();
    }

    // Utility function to redraw game
    private void draw() {
        for (int row = 0; row < ROWS; row++) {
            String sticks = "";
            for (int j = 0; j < nim.getRow(row); j++) {
                sticks += "|   ";
            }
            gameFields[row].setText(sticks);
        }
        rowField.setText("");
        sticksField.setText("");
    }

    public void actionPerformed(ActionEvent e) {
   // Player move
        if (e.getSource() == playButton) {
            try{ //try will find anything that is 
            // Get the row and number of sticks to take
            int row = Integer.parseInt(rowField.getText())-1;
            int sticks = Integer.parseInt(sticksField.getText());
            
            // Play that move
            nim.play(row, sticks);
            
            // Redisplay the board and enable the AI button
            draw();
            playButton.setEnabled(false);
            AIButton.setEnabled(true);
            
                
            }
            catch(IllegalSticksException ex){
                JOptionPane.showMessageDialog(null, "Sorry, you didnt take the allowed amount of sticks");
            }
            catch(NoSuchRowException ex){
                JOptionPane.showMessageDialog(null, "Sorry, there is no row there.");
            }
            catch(NotEnoughSticksException ex){
                JOptionPane.showMessageDialog(null, "Sorry, there is not enough sticks for you to take.");
            }
            catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(null, "Sorry, you have to use a number.");
            }
            // Determine whether the game is over
            if (nim.isOver()) {
                JOptionPane.showMessageDialog(null, "You lose!");
                playButton.setEnabled(false);
            }
        }
        
        // Computer move
        if (e.getSource() == AIButton) {
            
            // Determine computer move
            nim.AIMove();
            
            // Redraw board
            draw();
            AIButton.setEnabled(false);
            playButton.setEnabled(true);
            
            // Is the game over?
            if (nim.isOver()) {
                JOptionPane.showMessageDialog(null, "You win!");
                playButton.setEnabled(false);
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NimApp a = new NimApp();
    }
}