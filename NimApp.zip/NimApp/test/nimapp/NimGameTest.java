/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nimapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Candace
 */
public class NimGameTest {
    
    public NimGameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getRow method, of class NimGame.
     */
    @Test
    public void testGetRow() {
        System.out.println("getRow");
        int r = 0;
        NimGame instance = new NimGame (new int[]{5, 7, 9});
        int expResult = 5;
        int result = instance.getRow(r);
        assertEquals(expResult, result);
       
        //fail("GetRow method did not pass.");
    }

    
    @Test
    public void testPlay() {
        System.out.println("play");
        int r = 1;
        int s = 2;
        NimGame instance = new NimGame (new int[]{5, 7, 9});
        instance.play(r, s);
        instance.toString();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testPlay2() {
        System.out.println("play");
        int r = 4;
        int s = 2;
        NimGame instance = new NimGame (new int[]{5, 7, 9});
        try{
            instance.play(r, s);
        
        instance.toString();
        }
        catch(NotEnoughSticksException ex){
            
        }
        catch(NoSuchRowException ex){
            
        }
        catch(IllegalSticksException ex){
            
        }
        
        
    }
    
    
    
    /*
    @Test
    public void testIsOver() {
        System.out.println("isOver");
        NimGame instance = null;
        boolean expResult = false;
        boolean result = instance.isOver();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    @Test
    public void testAIMove() {
        System.out.println("AIMove");
        NimGame instance = null;
        instance.AIMove();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testToString() {
        System.out.println("toString");
        NimGame instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
 */   
}
