package edu.ncsu.csc326.coffeemaker;

import static org.junit.Assert.*;

import org.junit.Test;

public class testing {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
    ///    public void add_recipe(){
       //     Recipe[] r = new Recipe[2];
            
            
            
        //}
}
//add a recipe
//Delete a Recipe
//Edit a Recipe
//Add Inventory
//Check Inventory
//Purchase Coffee